import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import AppBar from '@mui/material/AppBar';
import CssBaseline from '@mui/material/CssBaseline';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Controls from '../Controls';
import LogoutIcon from '@mui/icons-material/Logout';
import { useNavigate } from 'react-router-dom';
import { IconButton, Tooltip } from '@mui/material';
import EmojiPeopleIcon from '@mui/icons-material/EmojiPeople';
import Badge from '@mui/material/Badge';
import { useState } from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import { styled } from '@mui/material/styles';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import ButtonBase from '@mui/material/ButtonBase';
import Customer from '../../images/Customer.jpeg';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { useEffect } from 'react';
import * as DriverService from '../../services/driver.js';

const drawerWidth = 240;

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));

const rows = [
    {
        "rideremail": "abc@gmail.com",
        "ridermobile": "7678786783",
        "pickup": "Indira Nagar",
        "drop": "Tin Factory",
        "fare": "480"
    },
    {
        "rideremail": "abcd@gmail.com",
        "ridermobile": "7678786783",
        "pickup": "Indira Nagar",
        "drop": "Tin Factory",
        "fare": "480"
    },
    {
        "rideremail": "abce@gmail.com",
        "ridermobile": "7678786783",
        "pickup": "Indira Nagar",
        "drop": "Tin Factory",
        "fare": "480"
    },
    {
        "rideremail": "abcf@gmail.com",
        "ridermobile": "7678786783",
        "pickup": "Indira Nagar",
        "drop": "Tin Factory",
        "fare": "480"
    },
    {
        "rideremail": "abcg@gmail.com",
        "ridermobile": "7678786783",
        "pickup": "Indira Nagar",
        "drop": "Tin Factory",
        "fare": "480"
    }
];

const IOSSwitch = styled((props) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
  ))(({ theme }) => ({
    width: 42,
    height: 26,
    padding: 0,
    '& .MuiSwitch-switchBase': {
      padding: 0,
      margin: 2,
      transitionDuration: '300ms',
      '&.Mui-checked': {
        transform: 'translateX(16px)',
        color: '#fff',
        '& + .MuiSwitch-track': {
          backgroundColor: theme.palette.mode === 'dark' ? '#2ECA45' : '#65C466',
          opacity: 1,
          border: 0,
        },
        '&.Mui-disabled + .MuiSwitch-track': {
          opacity: 0.5,
        },
      },
      '&.Mui-focusVisible .MuiSwitch-thumb': {
        color: '#33cf4d',
        border: '6px solid #fff',
      },
      '&.Mui-disabled .MuiSwitch-thumb': {
        color:
          theme.palette.mode === 'light'
            ? theme.palette.grey[100]
            : theme.palette.grey[600],
      },
      '&.Mui-disabled + .MuiSwitch-track': {
        opacity: theme.palette.mode === 'light' ? 0.7 : 0.3,
      },
    },
    '& .MuiSwitch-thumb': {
      boxSizing: 'border-box',
      width: 22,
      height: 22,
    },
    '& .MuiSwitch-track': {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === 'light' ? '#E9E9EA' : '#39393D',
      opacity: 1,
      transition: theme.transitions.create(['background-color'], {
        duration: 500,
      }),
    },
  }));

export default function DriverHomePage() {

    const [option, setOption] = useState();

    const [availability, setAvailability] = useState(false);

    const navigate = useNavigate();

    const MINUTE_MS = 1000;

    const [location, setLocation] = useState({
        latitude: 0,
        longitude: 0
    });

    const handleAvailability = (event) => {
        setAvailability(event.target.checked);
    };

    function randomNumberInRange(min, max) {
        // get number between min (inclusive) and max (inclusive)
        return (Math.random() * (max - min + 1)) + min;
    }

    useEffect(() => {
        if(availability){
        const interval = setInterval(() => {
            setLocation({latitude: randomNumberInRange(-90,90),longitude: randomNumberInRange(-180,180)});
            DriverService.updateLocation(location);
        }, MINUTE_MS);
        return () => {
            clearInterval(interval);
        };
    }
    }, [location, availability])

    return (
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />
            <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1, marginTop: '60px', bgcolor: "black" }}>
                <Toolbar>
                    <Typography variant="h6" noWrap component="div">
                        Welcome to Driver Home Page
                    </Typography>
                    <Tooltip title="Logout">
                        <IconButton style={{ marginLeft: "auto" }} onClick={() => { navigate('/driverLogin') }}>
                            <LogoutIcon fontSize='medium' style={{ color: "white" }} />
                        </IconButton>
                    </Tooltip>
                </Toolbar>
            </AppBar>
            <Drawer
                variant="permanent"
                sx={{
                    width: drawerWidth,
                    flexShrink: 0,
                    [`& .MuiDrawer-paper`]: {
                        width: drawerWidth, boxSizing: 'border-box',
                        marginTop: '70px'
                    },
                }}
            >
                <Toolbar />
                <Box sx={{ overflow: 'auto' }}>
                    <List>
                        <ListItem disablePadding>
                            <ListItemButton onClick={() => { setOption("Riders") }}>
                                <ListItemText primary="Riders" />
                                {
                                    <Badge badgeContent={4} color="secondary">
                                        <EmojiPeopleIcon fontSize='medium' />
                                    </Badge>
                                }
                            </ListItemButton>
                        </ListItem>
                        <ListItem disablePadding>
                            <ListItemButton onClick={() => { setOption("Availability") }}>
                                <ListItemText primary="Availability" />
                            </ListItemButton>
                        </ListItem>
                    </List>
                </Box>
            </Drawer>
            <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                <Toolbar />
                {option == 'Riders' && (availability ?
                    <>
                        <TableContainer component={Paper}>
                            <Table sx={{ minWidth: 700 }} aria-label="customized table">
                                <TableHead>
                                    <TableRow>
                                        <StyledTableCell>Rider Email</StyledTableCell>
                                        <StyledTableCell align="left">Rider Mobile No</StyledTableCell>
                                        <StyledTableCell align="left">Pickup</StyledTableCell>
                                        <StyledTableCell align="left">Drop</StyledTableCell>
                                        <StyledTableCell align="left">Fare</StyledTableCell>
                                        <StyledTableCell align="left">Action</StyledTableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {rows.map((row) => (
                                        <StyledTableRow key={row.rideremail}>
                                            <StyledTableCell component="th" scope="row">
                                                {row.rideremail}
                                            </StyledTableCell>
                                            <StyledTableCell align="left">{row.ridermobile}</StyledTableCell>
                                            <StyledTableCell align="left">{row.pickup}</StyledTableCell>
                                            <StyledTableCell align="left">{row.drop}</StyledTableCell>
                                            <StyledTableCell align="left">{row.fare}</StyledTableCell>
                                            <StyledTableCell align="left">
                                                <Controls.Button type='submit' style={{ marginRight: "10px" }}>Accept</Controls.Button>
                                                <Controls.Button color='error'>Deny</Controls.Button>
                                            </StyledTableCell>
                                        </StyledTableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </>
                    :
                    <h1>Currently you are NOT AVAILABLE for rides</h1>
                )
                }
                {option == 'Availability' &&
                    <>
                        <h4>Are you currently available for rides</h4>
                        <FormGroup>
                            <Stack direction="row" spacing={1} style={{ margin: 'auto' }} >
                                <Typography>No</Typography>
                                <IOSSwitch sx={{ m: 1 }} 
                                    checked={availability}
                                    onChange={handleAvailability} />
                                <Typography>Yes</Typography>
                            </Stack>
                        </FormGroup>
                    </>
                }

            </Box>
        </Box>
    );
}
