import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import AppBar from '@mui/material/AppBar';
import CssBaseline from '@mui/material/CssBaseline';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Controls from './Controls';
import LogoutIcon from '@mui/icons-material/Logout';
import { useNavigate } from 'react-router-dom';
import { Button, Card, IconButton, TextField, Tooltip } from '@mui/material';
import { Pagination } from "@mui/material";
import MenuItem from '@mui/material/MenuItem';
import { Divider } from "@material-ui/core";
import { display } from '@mui/system';
import axios from 'axios';

const drawerWidth = 240;

//generate random coordinate in given range
const getRandomCoordinate = (from, to, fixed) =>{
    return (Math.random()*(to-from)+from).toFixed(fixed)*1; 
}


//api requests
function getRideHistory(){
    return axios.get('api/rider/history', { params: { email: '' } });
}
function getNearbyCabs(){
    return axios.get('api/rider/nearbycabs', { params: { email: '', latitude:'', longitude:'' } });
}
function bookRide(){
        axios.post('/api/rider/book', {
        email: '',
        cabType:'',
        source: '',
        destination: ''
        
      })
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });
}




const cabTypes = [
  {
    value: 'SUV',
    baseFare: 150,
    perKmFare: 6
  },
  {
    value: 'HatchBack',
    baseFare: '75',
    perKmFare: 8
  },
  {
    value: 'Sedan',
    baseFare: '115',
    perKmFare: 10
  },
];

const rideHistory =[
    {
        from:'a',
        to:'b'
    },
    {
        from:'c',
        to:'d'
    },
    {
        from:'e',
        to:'f'
    },
    {
        from:'g',
        to:'h'
    },
    {
        from:'i',
        to:'j'
    },
    {
        from:'k',
        to:'l'
    },
    {
        from:'m',
        to:'n'
    },
    {
        from:'o',
        to:'p'
    },
];


function RiderHome() {

    const navigate = useNavigate();
    const [opt, setOpt] = React.useState('Get a Ride');
    const [bookingstatus, setBookingSatus] = React.useState('');
    const [cabtype, setCabType] = React.useState('');
    const [destination, setDestination] = React.useState('');
    const [source, setSOurce] = React.useState('');
    const itemsPerPage = 3;
    const [page, setPage] = React.useState(1);
    const [noOfPages] = React.useState(
    Math.ceil(rideHistory.length / itemsPerPage)
  );

  const getPage = (event, value) => {
    setPage(value);
  };

    const getCabType = (event) =>{
        setCabType(event.target.value);
    }

    const getDestination = (event) =>{
        setDestination(event.target.value);
    }

    const getSource = (event) =>{
        setSOurce(event.target.value);
    }

    const getBookingSatus = () =>{
        setBookingSatus('Waiting');
    }

    const getOpt = (obj) =>{
        setOpt(obj.target.outerText);
    }

    const interval = setInterval(function(){

        //if booking completed, aaaaaaaaaaaaaaas clearInterval(interval)
    },1000);
    
 

    return (
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />
            <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1, marginTop: '70px', bgcolor: "black" }}>
                <Toolbar>
                    <Typography variant="h6" noWrap component="div">
                        Welcome to Rider Home Page
                    </Typography>
                    <Tooltip title="Logout">
                        <IconButton style={{ marginLeft: "auto" }} onClick={() => { navigate('/') }}>
                            <LogoutIcon fontSize='medium' style={{ color: "white" }} />
                        </IconButton>
                    </Tooltip>
                </Toolbar>
            </AppBar>
            <Drawer
                variant="permanent"
                sx={{
                    width: drawerWidth,
                    flexShrink: 0,
                    [`& .MuiDrawer-paper`]: {
                        width: drawerWidth, boxSizing: 'border-box',
                        marginTop: '70px'
                    },
                }}
            >
                <Toolbar />
                <Box sx={{ overflow: 'auto' }}>
                    <List>
                        {['Get a Ride', 'Ride History'].map((text, index) => (
                            <ListItem key={text} disablePadding>
                                <ListItemButton onClick={(text,index) => { getOpt(text); }}>
                                    <ListItemText primary={text} />
                                </ListItemButton>
                            </ListItem>
                        ))}
                    </List>
                </Box>
            </Drawer>
            <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                <Toolbar />
                <div>
                    
                    {
                    (opt==='Get a Ride') ?
                    <div>
                        <Card sx={{ width: '100%', maxWidth: '600px', margin: "auto", border:'groove', padding:'20px', display:'flexGrow' }}>
                        <h4>Select a Cab Type</h4>
                            
                            <div>
                            <div>
                                {
                                    cabTypes.map(({value, baseFare, perKmFare}) => (
                                        <Card sx={{ margin: "20px", padding:'20px' }}>
                                        <input type='radio' key={value} value={value} name='cabtyperadio' onChange={getCabType} >
                                        </input>
                                        <label>
                                            {value} 
                                            {(cabtype===value)?<span style={{color:'red'}}>{<p></p>} Base Fare : {baseFare} Fare/Km : {perKmFare}</span> :null}
                                        </label> 
                                        </Card>
                                    ))
                                }
                            </div>
                            {(cabtype===' ')?null:
                            <div style={{display:'flex'}}>
                            <TextField id="src-basic" label="Source" variant="outlined" type="search" onInput={getSource} style={{margin:'20px'}}>
                                Source
                            </TextField>
                            <TextField id="dest-basic" label="Destination" variant="outlined" type="search" onInput={getDestination} style={{margin:'20px'}}>
                                Destination
                            </TextField>
                            </div>}
                            {(bookingstatus=='' && !(source==='' || destination==='' || cabtype===''))?<Controls.Button style={{margin:'30px'}} onClick={getBookingSatus}>Book Ride</Controls.Button>:null}
                            {(bookingstatus=='Waiting')?<span style={{color:'blueviolet'}}>Finding a driver for you</span>:null}
                            {(bookingstatus=='Success')?<span style={{color:'green'}}>Booking Successful!</span>:null}
                            </div>
                            
                        
                        </Card>
                    </div>
                    :
                    <div>
                        <List>
                            {rideHistory
                            .slice((page - 1) * itemsPerPage, page * itemsPerPage)
                            .map(rideHistory => {
                                return (
                                <ListItem
                                    key={rideHistory.to}
                                    button
                                    onClick={() => console.log({rideHistory})}
                                >
                                    <ListItemText
                                    id={rideHistory.from + "to" + rideHistory.to }
                                    primary={ rideHistory.from + "to" + rideHistory.to  }
                                    secondary={
                                        "ride details here"
                                    }
                                    />
                    
                                </ListItem>
                                );
                            })}
                        </List>
                        <Divider />
                        <Box component="span">
                            <Pagination
                            count={noOfPages}
                            page={page}
                            onChange={getPage}
                            defaultPage={1}
                            color="primary"
                            size="large"
                            showFirstButton
                            showLastButton
                            />
                        </Box>
                        </div>}
                </div>

            </Box>
        </Box>
    );
}


export default RiderHome;


//for select list
/*<TextField
                                id="outlined-select-cabtype"
                                select
                                label="Select Cab Type"
                                value={cabtype}
                                onChange={getCabType}
                                helperText="Please select a cab type"
                                style={{margin:'20px'}}
                                >
                                {cabTypes.map((option) => (
                                    <MenuItem key={option.value} value={option.value}>
                                    {option.value}
                                    </MenuItem>
                                ))}
                            </TextField>*/