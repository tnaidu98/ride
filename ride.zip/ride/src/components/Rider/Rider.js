import Controls from "../Controls";
import {
  Button,
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  CardMedia,
  Typography,
} from "@mui/material";

import * as Yup from 'yup';
import { Form, Formik } from "formik";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const SigninSchema = Yup.object().shape({
  username: Yup.string().min(2, 'Too Short!').max(30, 'Too Long!').required('Required'),
  password: Yup.string().min(2, 'Too Short!').max(30, 'Too Long!').required('Required'),
});

const RegistrationSchema = Yup.object().shape({
  firstname: Yup.string().min(2, 'Too Short!').max(30, 'Too Long!').required('Required'),
  lastname: Yup.string().min(2, 'Too Short!').max(30, 'Too Long!').required('Required'),
  email: Yup.string().email('Invalid email').required('Required'),
  mobile: Yup.number().min(1000000000, 'Invalid').max(9999999999, 'Invalid').required('Required'),
  password: Yup.string().min(8, 'Too Short!').max(20, 'Too Long!').required('Required'),
  confirmpassword: Yup.string().min(8, 'Too Short!').max(20, 'Too Long!').required('Required'),
});

function Rider() {

  const [userdetails, setUserdetails] = useState({});
  const [registerUser, setRegisterUser] = useState(false);
  const navigate = useNavigate();

  const getdetails = (values) =>{
    setUserdetails(userdetails);
  }

  const registerUserOnClick =()=>{
      setRegisterUser(!registerUser);
  }

    return (
      <div className="Rider">
        <h1 style={{fontFamily:'Nunito Sans'}}></h1>
        <div className="LoginRegister" style={{margin: "auto"}}>
          <div className="LoginForm" style={{ width:'35%', margin: "auto", display:'1' }}>
          {registerUser?<Formik initialValues={{
                firstname: '',
                lastname: '',
                password: '',
                confirmpassword: '',
                email: '',
                mobile: '',
              }}
  
              validationSchema={RegistrationSchema}
              onSubmit={values => {
                getdetails(values);
                console.log(values);
                navigate('/rider/Home');
              }}
              >
                <Form>
                  <Card sx={{ width: '100%', maxWidth: '600px', margin: "auto", marginTop: "20px", border:'groove' }}>
                  <CardActionArea>
                      <CardContent>
                        <Typography gutterBottom variant='h5' component='div'>
                          Register Here!
                        </Typography>
                        <Typography variant='outlined' color='text.secondary'>
                          <div style={{justifyContent:"space-evenly"}}>
                            <Controls.TextField name='firstname' label='First Name' style={{marginTop:'5px'}} />
                            <Controls.TextField name='lastname' label='Last Name' style={{marginTop:'5px'}} />
                          </div>
                          <div style={{ justifyContent:"space-around"}}>
                            <Controls.TextField name='email' label='Email' style={{marginTop:'5px'}}/>
                            <Controls.TextField name='mobile' label='Mobile No.' style={{marginTop:'5px'}}/>
                          </div>
                          <div style={{ justifyContent:"space-around"}}>
                          <Controls.TextField name='password' type='password' label='Password' style={{marginTop:'5px'}} />
                          <Controls.TextField name='confirmpassword' type='password' label='Confirm Password' style={{marginTop:'5px'}} />
                          </div>
                        </Typography>
                      </CardContent>
                    <CardActions>
                      <Controls.Button type='submit'>Register</Controls.Button>
                    </CardActions>
                    </CardActionArea>
                  </Card>
                </Form>
              </Formik>:<Formik initialValues={{
              username: '',
              password: '',
            }}
            validationSchema={SigninSchema}
            onSubmit={values => {
              getdetails(values);
              console.log(values);
              navigate('/rider/Home');
            }}
            >
              <Form >
                <Card sx={{ maxWidth: 345, margin: "auto", marginTop: "20px", border:'groove'}} >
                  <CardActionArea>
                    <CardContent>
                      <Typography gutterBottom variant='h5' component='div'>
                        Login!
                      </Typography>
                      <Typography variant='body2' color='text.secondary'>
                        <Controls.TextField name='username' label='Username'  />
                        <br/>
                        <br/>
                        <Controls.TextField
                          name='password'
                          type='password'
                          label='Password'
                        />
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                  <CardActions>
                    <Controls.Button type='submit'>Login</Controls.Button>
                  </CardActions>
                </Card>
              </Form>
            </Formik>}
          </div>
          <div className="RegisterForm" style={{ margin: "auto" }}>
            <br/>
            <Controls.Button disabled style={{backgroundColor:'orange',color:'whitesmoke' , margin: "auto" }}
            onClick={registerUserOnClick}>
            {registerUser?<>Already a User? Login Here!</>:<>New User? Register Here!</>}
            </Controls.Button>
          </div>
        </div>
      </div>
    );
  }
  
  export default Rider;