import Controls from "./Controls";
import App from "../App";
import { useNavigate } from "react-router-dom";
import RiderImage from "../images/RiderImage.png";
import DriverImage from "../images/DriverImage.png";

import { Card, CardActionArea, CardMedia, CardContent, Typography } from "@mui/material";



function Welcome({ user, setUser }) {

    const navigate = useNavigate();

    return (
        <>
        <h1>Choose the User</h1>
        <div className="Welcome" style={{ marginTop: "60px", display: "flex", flexWrap: "wrap", alignItems: 'center', justifyContent: 'center' }}>
            <Card sx={{ maxWidth: 345, marginRight:"20px" }}>
                <CardActionArea onClick={() => { setUser("rider"); navigate('/rider') }} >
                    <CardMedia
                        component="img"
                        image={RiderImage}
                        sx={{ height: 250 }}
                    />
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                            RIDER
                        </Typography>
                    </CardContent>
                </CardActionArea>
            </Card>
            <Card sx={{ maxWidth: 345 }}>
                <CardActionArea onClick={() => { setUser("driver"); navigate('/driverLogin') }} >
                    <CardMedia
                        component="img"
                        image={DriverImage}
                        sx={{ height: 250 }}
                    />
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                            DRIVER
                        </Typography>
                    </CardContent>
                </CardActionArea>
            </Card>
        </div>
        </>
    );
}

export default Welcome;