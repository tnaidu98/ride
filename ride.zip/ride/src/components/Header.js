import React from "react";

export const Header = () => {
  return (
      <h1 style={{ backgroundColor: 'orange', height: "60px", margin:"0" }}>Cab Booking App</h1>
  );
};