import Axios from "../custom/Axios";

export async function updateLocation(params) {
  console.log(params);
  const res = await Axios.post('location',params)
    .then(res => console.log(res))
    .catch((error) => console.log(error));
  console.log(res);
  return params;
}
