import { Axios } from "axios";

export async function login(params) {
  console.log(params);
  const res = await Axios.get("posts/1")
    .then((data) => {
      return data.data;
    })
    .catch((error) => console.log(error));
  console.log(res);
  return params;
}
